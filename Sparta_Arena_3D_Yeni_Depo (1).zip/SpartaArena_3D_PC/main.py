"""SPARTA ARENA — 3D PC EDITION
A lightweight, real-time 3D arena prototype built with Panda3D.
The complete original V57 Pygame game is bundled separately as SpartaArenaV57.exe.
"""
from __future__ import annotations

import json
import math
import os
import random
import subprocess
import sys
import time
from pathlib import Path

from panda3d.core import (
    loadPrcFileData, AmbientLight, DirectionalLight, Fog, Vec3, Vec4,
    Geom, GeomNode, GeomTriangles, GeomVertexData, GeomVertexFormat,
    GeomVertexWriter, GeomVertexReader, NodePath, KeyboardButton, MouseButton,
    TransparencyAttrib, Point3, TextNode, WindowProperties, ClockObject,
)
from direct.showbase.ShowBase import ShowBase
from direct.showbase.ShowBaseGlobal import globalClock
from direct.gui.DirectGui import DirectButton, DirectFrame, DirectLabel, DirectWaitBar, DGG
from direct.gui.OnscreenImage import OnscreenImage

PROJECT_DIR = Path(__file__).resolve().parent

def resource_path(*parts: str) -> str:
    base = Path(getattr(sys, "_MEIPASS", PROJECT_DIR))
    return str(base.joinpath(*parts))

def user_data_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    path = base / "SpartaArena"
    path.mkdir(parents=True, exist_ok=True)
    return path

DATA_DIR = user_data_dir()
SETTINGS_PATH = DATA_DIR / "settings_3d.json"
PROGRESS_PATH = DATA_DIR / "progress_3d.json"

loadPrcFileData("SpartaArena", """
window-title SPARTA ARENA - 3D PC
win-size 1440 810
sync-video true
show-frame-rate-meter false
notify-level warning
framebuffer-multisample 1
multisamples 2
""")

DEFAULT_BINDINGS = {
    "forward": "w", "back": "s", "left": "a", "right": "d",
    "attack": "mouse1", "block": "shift", "potion": "q",
    "full_potion": "e", "pause": "escape",
}
ACTION_LABELS = {
    "forward": "İLERİ HAREKET", "back": "GERİ HAREKET",
    "left": "SOLA HAREKET", "right": "SAĞA HAREKET",
    "attack": "SALDIRI", "block": "SAVUNMA / BLOK",
    "potion": "İKSİR KULLAN", "full_potion": "TAM CAN İKSİRİ",
    "pause": "DURAKLAT / MENÜ",
}
KEY_EVENTS = list("abcdefghijklmnopqrstuvwxyz0123456789") + [
    "space", "shift", "control", "alt", "escape", "enter", "tab",
    "backspace", "arrow_up", "arrow_down", "arrow_left", "arrow_right",
    "home", "end", "insert", "delete", "page_up", "page_down",
    "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12",
    "mouse1", "mouse2", "mouse3",
]


def read_json(path: Path, default: dict) -> dict:
    try:
        with path.open("r", encoding="utf-8") as fh:
            loaded = json.load(fh)
        return loaded if isinstance(loaded, dict) else dict(default)
    except (OSError, ValueError, TypeError):
        return dict(default)


def atomic_write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def vec_len2(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def build_mesh(parent: NodePath, name: str, vertices, triangles, color, normals=None) -> NodePath:
    fmt = GeomVertexFormat.getV3n3c4()
    data = GeomVertexData(name, fmt, Geom.UHStatic)
    data.setNumRows(len(vertices))
    vw = GeomVertexWriter(data, "vertex")
    nw = GeomVertexWriter(data, "normal")
    cw = GeomVertexWriter(data, "color")
    for index, p in enumerate(vertices):
        vw.addData3f(float(p[0]), float(p[1]), float(p[2]))
        if normals is not None:
            n = normals[index]
        else:
            mag = math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) or 1.0
            n = (p[0] / mag, p[1] / mag, p[2] / mag)
        nw.addData3f(float(n[0]), float(n[1]), float(n[2]))
        cw.addData4f(float(color[0]), float(color[1]), float(color[2]), float(color[3]))
    prim = GeomTriangles(Geom.UHStatic)
    for tri in triangles:
        prim.addVertices(int(tri[0]), int(tri[1]), int(tri[2]))
    prim.closePrimitive()
    geom = Geom(data)
    geom.addPrimitive(prim)
    node = GeomNode(name)
    node.addGeom(geom)
    result = parent.attachNewNode(node)
    result.setTwoSided(True)
    return result


def make_box(parent, name, width, depth, height, color) -> NodePath:
    x, y, z = width / 2.0, depth / 2.0, height / 2.0
    faces = [
        ([(-x,-y,-z),(x,-y,-z),(x,-y,z),(-x,-y,z)], (0,-1,0)),
        ([(x,y,-z),(-x,y,-z),(-x,y,z),(x,y,z)], (0,1,0)),
        ([(-x,y,-z),(-x,-y,-z),(-x,-y,z),(-x,y,z)], (-1,0,0)),
        ([(x,-y,-z),(x,y,-z),(x,y,z),(x,-y,z)], (1,0,0)),
        ([(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)], (0,0,1)),
        ([(-x,y,-z),(x,y,-z),(x,-y,-z),(-x,-y,-z)], (0,0,-1)),
    ]
    verts, norms, tris = [], [], []
    for face, normal in faces:
        start = len(verts)
        verts.extend(face)
        norms.extend([normal] * 4)
        tris.extend([(start, start + 1, start + 2), (start, start + 2, start + 3)])
    return build_mesh(parent, name, verts, tris, color, norms)


def make_sphere(parent, name, color, slices=14, stacks=9) -> NodePath:
    verts, norms, tris = [], [], []
    for i in range(stacks + 1):
        theta = math.pi * i / stacks
        for j in range(slices + 1):
            phi = 2.0 * math.pi * j / slices
            x = 0.5 * math.sin(theta) * math.cos(phi)
            y = 0.5 * math.sin(theta) * math.sin(phi)
            z = 0.5 * math.cos(theta)
            verts.append((x, y, z))
            length = math.sqrt(x*x+y*y+z*z) or 1.0
            norms.append((x/length, y/length, z/length))
    for i in range(stacks):
        for j in range(slices):
            a = i * (slices + 1) + j
            b = a + slices + 1
            tris.extend([(a, b, a + 1), (a + 1, b, b + 1)])
    return build_mesh(parent, name, verts, tris, color, norms)


def make_cylinder(parent, name, color, slices=18) -> NodePath:
    verts, norms, tris = [], [], []
    for z in (0.0, 1.0):
        for i in range(slices):
            a = math.tau * i / slices
            verts.append((0.5 * math.cos(a), 0.5 * math.sin(a), z))
            norms.append((math.cos(a), math.sin(a), 0))
    for i in range(slices):
        nxt = (i + 1) % slices
        tris.extend([(i, nxt, slices + i), (nxt, slices + nxt, slices + i)])
    # Separate flat caps give the cylinder cleaner lighting.
    bottom_center = len(verts)
    verts.append((0, 0, 0)); norms.append((0, 0, -1))
    bottom_start = len(verts)
    for i in range(slices):
        a = math.tau * i / slices
        verts.append((0.5 * math.cos(a), 0.5 * math.sin(a), 0)); norms.append((0, 0, -1))
    top_center = len(verts)
    verts.append((0, 0, 1)); norms.append((0, 0, 1))
    top_start = len(verts)
    for i in range(slices):
        a = math.tau * i / slices
        verts.append((0.5 * math.cos(a), 0.5 * math.sin(a), 1)); norms.append((0, 0, 1))
    for i in range(slices):
        nxt = (i + 1) % slices
        tris.append((bottom_center, bottom_start + nxt, bottom_start + i))
        tris.append((top_center, top_start + i, top_start + nxt))
    return build_mesh(parent, name, verts, tris, color, norms)


def make_torus(parent, name, major_radius, tube_radius, color, major_segments=64, tube_segments=8) -> NodePath:
    verts, norms, tris = [], [], []
    for i in range(major_segments + 1):
        u = math.tau * i / major_segments
        cu, su = math.cos(u), math.sin(u)
        for j in range(tube_segments + 1):
            v = math.tau * j / tube_segments
            cv, sv = math.cos(v), math.sin(v)
            radius = major_radius + tube_radius * cv
            verts.append((radius * cu, radius * su, tube_radius * sv))
            norms.append((cv * cu, cv * su, sv))
    stride = tube_segments + 1
    for i in range(major_segments):
        for j in range(tube_segments):
            a = i * stride + j
            b = a + stride
            tris.extend([(a, b, a + 1), (a + 1, b, b + 1)])
    return build_mesh(parent, name, verts, tris, color, norms)


def make_disk(parent, name, radius, z, color, segments=72) -> NodePath:
    verts = [(0, 0, z)]
    norms = [(0, 0, 1)]
    tris = []
    for i in range(segments):
        a = math.tau * i / segments
        verts.append((radius * math.cos(a), radius * math.sin(a), z))
        norms.append((0, 0, 1))
    for i in range(segments):
        tris.append((0, i + 1, (i + 1) % segments + 1))
    return build_mesh(parent, name, verts, tris, color, norms)


class SpartaArena3D(ShowBase):
    def __init__(self):
        super().__init__()
        self.disableMouse()
        self.setBackgroundColor(0.055, 0.075, 0.11, 1)
        self.camLens.setFov(72)
        self.camLens.setNearFar(0.1, 500)
        self.render.setShaderAuto()
        self.setFrameRateMeter(False)
        globalClock.setMode(ClockObject.MLimited)
        globalClock.setFrameRate(60)

        self.settings = read_json(SETTINGS_PATH, {"bindings": DEFAULT_BINDINGS, "quality": "Orta", "sound": True})
        if not isinstance(self.settings.get("bindings"), dict):
            self.settings["bindings"] = dict(DEFAULT_BINDINGS)
        for action, key in DEFAULT_BINDINGS.items():
            self.settings["bindings"].setdefault(action, key)
        self.settings.setdefault("quality", "Orta")
        self.settings.setdefault("sound", True)
        self.bindings = self.settings["bindings"]
        self.progress = read_json(PROGRESS_PATH, {"gold": 500, "wins": 0, "classic_round": 1, "endless_kills": 0, "boss_wins": 0, "achievements": []})
        self.progress.setdefault("gold", 500)
        self.progress.setdefault("wins", 0)
        self.progress.setdefault("classic_round", 1)
        self.progress.setdefault("endless_kills", 0)
        self.progress.setdefault("boss_wins", 0)
        self.progress.setdefault("achievements", [])

        self.gui = []
        self.cover_img = None
        self.capture_action = None
        self.mode = "classic"
        self.game_state = "menu"
        self.player_root = None
        self.enemy_root = None
        self.player_weapon = None
        self.enemy_weapon = None
        self.flames = []
        self.particles = []
        self.player_hp = 100.0
        self.enemy_hp = 100.0
        self.player_potions = 3
        self.full_potions = 1
        self.player_damage = 22.0
        self.enemy_damage = 7.0
        self.player_attack_cd = 0.0
        self.enemy_attack_cd = 0.0
        self.hit_flash = 0.0
        self.enemy_hit_flash = 0.0
        self.round_number = 1
        self.round_time = 0.0
        self.hill_time_left = 120.0
        self.enemy_scale = 1.0
        self.prev_action = {}
        self.last_hud_update = 0.0
        self.hud_labels = {}
        self.result_reason = ""
        self.notice_until = 0.0
        self.notice_label = None
        self.world_root = self.render.attachNewNode("SpartaArena3DWorld")
        self._setup_lighting()
        self._build_arena()
        self._register_input_events()
        self.taskMgr.add(self.update, "sparta-arena-update")
        self.show_main_menu()

    def _setup_lighting(self):
        ambient = AmbientLight("warm-ambient")
        ambient.setColor(Vec4(0.42, 0.42, 0.48, 1))
        self.render.setLight(self.render.attachNewNode(ambient))
        sun = DirectionalLight("arena-sun")
        sun.setColor(Vec4(0.96, 0.84, 0.68, 1))
        sun.setDirection(Vec3(-1, -2, -3))
        sun_np = self.render.attachNewNode(sun)
        self.render.setLight(sun_np)
        fog = Fog("arena-haze")
        fog.setColor(0.10, 0.12, 0.17)
        fog.setExpDensity(0.008)
        self.render.setFog(fog)

    def _build_arena(self):
        arena = self.world_root
        make_disk(arena, "world-ground", 80, -0.40, (0.12, 0.17, 0.18, 1), 96)
        make_disk(arena, "arena-sand", 10.0, -0.02, (0.47, 0.36, 0.24, 1), 96)
        make_disk(arena, "inner-sand", 7.8, 0.005, (0.54, 0.42, 0.29, 1), 96)
        make_torus(arena, "arena-inner-rim", 7.8, 0.10, (0.67, 0.52, 0.29, 1))
        make_torus(arena, "arena-outer-rim", 10.05, 0.22, (0.70, 0.55, 0.34, 1))
        make_torus(arena, "arena-rim-dark", 10.38, 0.08, (0.19, 0.15, 0.12, 1))
        # Broad layered colosseum rings form the arena bowl.
        quality = self.settings.get("quality", "Orta")
        ring_defs = [(11.8, 0.46, 0.26), (13.0, 0.54, 0.90), (14.3, 0.52, 1.65), (15.5, 0.42, 2.35)]
        for i, (radius, tube, height) in enumerate(ring_defs):
            col = (0.39 + i * 0.035, 0.34 + i * 0.03, 0.28 + i * 0.03, 1)
            ring = make_torus(arena, f"stone-terrace-{i}", radius, tube, col)
            ring.setZ(height)
        make_torus(arena, "upper-wall-band", 16.25, 0.40, (0.43, 0.36, 0.28, 1)).setZ(3.15)
        column_count = 24 if quality == "Yüksek" else (16 if quality == "Orta" else 10)
        for i in range(column_count):
            angle = math.tau * i / column_count
            x, y = 16.05 * math.cos(angle), 16.05 * math.sin(angle)
            base = make_cylinder(arena, f"column-base-{i}", (0.53, 0.44, 0.33, 1))
            base.setScale(0.68, 0.68, 0.45); base.setPos(x, y, 3.15)
            shaft = make_cylinder(arena, f"column-shaft-{i}", (0.62, 0.53, 0.42, 1))
            shaft.setScale(0.43, 0.43, 4.15); shaft.setPos(x, y, 3.50)
            cap = make_cylinder(arena, f"column-cap-{i}", (0.70, 0.60, 0.46, 1))
            cap.setScale(0.70, 0.70, 0.40); cap.setPos(x, y, 7.55)
            # Alternating deep-red banners mounted between columns.
            if i % 2 == 0:
                banner = make_box(arena, f"banner-{i}", 1.25, 0.07, 2.5, (0.34, 0.035, 0.045, 1))
                banner.setPos(x * 0.96, y * 0.96, 5.55)
                banner.setH(math.degrees(angle) + 90)
                emblem = make_box(arena, f"banner-mark-{i}", 0.12, 0.09, 0.78, (0.82, 0.61, 0.20, 1))
                emblem.setPos(x * 0.96, y * 0.96 - 0.045, 5.60)
                emblem.setH(math.degrees(angle) + 90)
            if i % max(1, column_count // 8) == 0:
                torch = make_cylinder(arena, f"torch-stand-{i}", (0.19, 0.12, 0.08, 1))
                torch.setScale(0.18, 0.18, 1.15); torch.setPos(x * 0.78, y * 0.78, 0.0)
                flame = make_sphere(arena, f"torch-flame-{i}", (1.0, 0.33, 0.05, 1), 10, 7)
                flame.setScale(0.24, 0.24, 0.48); flame.setPos(x * 0.78, y * 0.78, 1.27)
                self.flames.append((flame, random.random() * math.tau))
        # Mountains and broken stone silhouettes create depth beyond the arena.
        random.seed(357)
        for i in range(22):
            angle = math.tau * i / 22
            radius = random.uniform(23, 29)
            peak = make_box(arena, f"distant-rock-{i}", random.uniform(2.5, 5.0), 2.4,
                            random.uniform(3.5, 8.0), (0.10, 0.15, 0.20, 1))
            peak.setPos(radius * math.cos(angle), radius * math.sin(angle), 1.3)
            peak.setH(-math.degrees(angle))

        self.camera.setPos(0, -24, 9)
        self.camera.lookAt(0, 0, 1.6)

    def _register_input_events(self):
        for event_name in KEY_EVENTS:
            self.accept(event_name, self._input_event, [event_name])

    def _input_event(self, event_name: str):
        if self.capture_action:
            action = self.capture_action
            self.capture_action = None
            if event_name == "escape":
                self.show_settings()
                self._notify("Tuş ataması iptal edildi")
            else:
                occupied = next((other for other, bound in self.bindings.items()
                                 if other != action and bound == event_name), None)
                if occupied:
                    self.show_settings()
                    self._notify(f"Bu tuş zaten kullanılıyor: {ACTION_LABELS[occupied]}")
                else:
                    self.bindings[action] = event_name
                    self.settings["bindings"] = self.bindings
                    atomic_write_json(SETTINGS_PATH, self.settings)
                    self.show_settings()
                    self._notify(f"{ACTION_LABELS[action]}: {self._key_label(event_name)}")
            return
        if event_name.startswith("mouse") and self.game_state == "playing":
            for action, binding in self.bindings.items():
                if binding == event_name:
                    self._perform_action(action)

    def _key_label(self, key: str) -> str:
        return {"mouse1":"SOL TIK", "mouse2":"SAĞ TIK", "mouse3":"ORTA TIK",
                "arrow_up":"YUKARI OK", "arrow_down":"AŞAĞI OK", "arrow_left":"SOL OK",
                "arrow_right":"SAĞ OK", "shift":"SHIFT", "control":"CTRL",
                "space":"SPACE", "escape":"ESC", "enter":"ENTER"}.get(key, key.upper())

    def _show_cover(self):
        if self.cover_img:
            try:
                self.cover_img.destroy()
            except Exception:
                pass
        path = resource_path("assets", "SpartaArena_Cover.jpg")
        if os.path.isfile(path):
            try:
                self.cover_img = OnscreenImage(image=path, pos=(0, 0, 0), scale=(1.78, 1, 1.0))
                self.cover_img.setTransparency(TransparencyAttrib.MAlpha)
                self.cover_img.setBin("background", 0)
            except Exception:
                self.cover_img = None

    def _hide_cover(self):
        if self.cover_img:
            try:
                self.cover_img.destroy()
            except Exception:
                pass
            self.cover_img = None

    def _clear_ui(self):
        for widget in self.gui:
            try:
                widget.destroy()
            except Exception:
                pass
        self.gui.clear()
        self.hud_labels.clear()
        self.notice_label = None

    def _label(self, text, pos=(0, 0, 0), scale=0.05, color=(1, 0.90, 0.70, 1), align=TextNode.ACenter, **kwargs):
        label = DirectLabel(text=text, pos=pos, scale=scale, text_fg=color,
                            text_align=align, frameColor=(0, 0, 0, 0), **kwargs)
        self.gui.append(label)
        return label

    def _button(self, text, pos, command, scale=0.047, width=11.0, color=(0.18, 0.12, 0.07, 0.96)):
        button = DirectButton(
            text=text, pos=pos, scale=scale, command=command,
            frameSize=(-width, width, -0.62, 0.62),
            frameColor=color, relief=DGG.RAISED,
            text_fg=(1.0, 0.84, 0.54, 1), text_shadow=(0, 0, 0, 0.7),
            textMayChange=True, pressEffect=True,
        )
        self.gui.append(button)
        return button

    def show_main_menu(self):
        self._clear_ui()
        self._hide_cover()
        self.game_state = "menu"
        self.camera.setPos(0, -24, 9); self.camera.lookAt(0, 0, 1.6)
        self._show_cover()
        # subtle translucent veil improves menu contrast without covering the title art
        veil = DirectFrame(frameColor=(0.015, 0.02, 0.035, 0.25),
                           frameSize=(-1.78, 1.78, -1.0, 1.0), pos=(0, 0, 0.0))
        self.gui.append(veil)
        self._label("GERÇEK 3D ARENA • V57 İÇERİK KORUNDU", (0, 0, -0.12), 0.036, (1, 0.83, 0.51, 1))
        self._button("3D ARENAYA GİR", (0, 0, -0.34), self.show_mode_select, 0.051, 11.0, (0.26, 0.11, 0.055, 0.98))
        self._button("V57 TAM İÇERİK • DÜNYA / DENİZ / MAĞAZA / BAŞARIMLAR", (0, 0, -0.50), self.launch_legacy, 0.034, 18.0)
        self._button("AYARLAR • TUŞ ATAMA", (0, 0, -0.65), self.show_settings, 0.037, 10.5)
        self._button("ÇIKIŞ", (0, 0, -0.80), self.userExit, 0.035, 5.0)

    def show_mode_select(self):
        self._hide_cover(); self._clear_ui(); self.game_state = "select_mode"
        self._label("3D ARENA MODUNU SEÇ", (0, 0, 0.82), 0.065, (1.0, 0.82, 0.45, 1))
        self._label("Klavye + fare • gerçek zamanlı 3D ışıklandırma • kayıtlı ilerleme", (0, 0, 0.70), 0.029)
        modes = [
            ("KLASİK TUR", "classic"), ("TEPENİN KRALI", "hill"),
            ("BOSS SAVAŞI", "boss"), ("SONSUZ MOD", "endless"),
        ]
        positions = [(-0.77, 0.39), (0.77, 0.39), (-0.77, 0.08), (0.77, 0.08)]
        for (label, key), pos in zip(modes, positions):
            self._button(label, (pos[0], 0, pos[1]), lambda k=key: self.start_battle(k), 0.042, 8.0)
        self._label("Dünya Fethi, şehirler, deniz, balıkçılık, mağaza, iksirler ve tüm V57 menüleri", (0, 0, -0.20), 0.030)
        self._button("TÜM V57 SİSTEMLERİNİ AÇ", (0, 0, -0.40), self.launch_legacy, 0.040, 12.0)
        self._button("GERİ", (0, 0, -0.67), self.show_main_menu, 0.038, 5.0)

    def show_settings(self):
        self._hide_cover(); self._clear_ui(); self.game_state = "settings"
        self._label("AYARLAR • KONTROLLER", (0, 0, 0.84), 0.062, (1, 0.82, 0.45, 1))
        self._label("Bir eyleme tıkla, ardından kullanmak istediğin tuşa veya fare düğmesine bas.", (0, 0, 0.73), 0.027)
        actions = list(ACTION_LABELS)
        for idx, action in enumerate(actions):
            col = idx % 2
            row = idx // 2
            x = -0.78 if col == 0 else 0.78
            z = 0.51 - row * 0.21
            label = f"{ACTION_LABELS[action]}   [{self._key_label(self.bindings[action])}]"
            self._button(label, (x, 0, z), lambda a=action: self._begin_capture(a), 0.031, 10.6,
                         (0.11, 0.12, 0.15, 0.97))
        self._button(f"GRAFİK KALİTESİ: {self.settings.get('quality','Orta').upper()}  • DEĞİŞTİR",
                     (0, 0, -0.55), self._cycle_quality, 0.033, 13.2)
        self._button("VARSAYILAN TUŞLAR", (-0.53, 0, -0.73), self._reset_bindings, 0.031, 8.0)
        self._button("GERİ", (0.56, 0, -0.73), self.show_main_menu, 0.034, 4.6)
        if self.capture_action:
            self._label(f"ŞİMDİ YENİ BİR TUŞA BAS: {ACTION_LABELS[self.capture_action]} (ESC İPTAL)",
                        (0, 0, -0.88), 0.027, (1, 0.35, 0.25, 1))

    def _begin_capture(self, action):
        self.capture_action = action
        self.show_settings()
        self._notify("Tuş seçimi bekleniyor")

    def _reset_bindings(self):
        self.bindings.clear(); self.bindings.update(DEFAULT_BINDINGS)
        self.settings["bindings"] = self.bindings
        atomic_write_json(SETTINGS_PATH, self.settings)
        self.capture_action = None
        self.show_settings()
        self._notify("Varsayılan tuşlar yüklendi")

    def _cycle_quality(self):
        options = ["Düşük", "Orta", "Yüksek"]
        current = self.settings.get("quality", "Orta")
        self.settings["quality"] = options[(options.index(current) + 1) % len(options)] if current in options else "Orta"
        atomic_write_json(SETTINGS_PATH, self.settings)
        self.show_settings()
        self._notify("Grafik kalitesi kaydedildi. Tam etki için oyunu yeniden başlat.")

    def _key_is_down(self, name):
        if name.startswith("mouse"):
            buttons = {"mouse1": MouseButton.one(), "mouse2": MouseButton.two(), "mouse3": MouseButton.three()}
            try:
                return self.mouseWatcherNode.is_button_down(buttons[name])
            except Exception:
                return False
        mapping = {
            "arrow_up": "up", "arrow_down": "down", "arrow_left": "left", "arrow_right": "right",
            "space": "space", "shift": "shift", "control": "control", "alt": "alt",
            "escape": "escape", "enter": "enter", "tab": "tab", "backspace": "backspace",
            "home": "home", "end": "end", "insert": "insert", "delete": "delete",
            "page_up": "pageUp", "page_down": "pageDown",
        }
        try:
            if len(name) == 1:
                button = KeyboardButton.asciiKey(name)
            else:
                fn_name = mapping.get(name, name)
                fn = getattr(KeyboardButton, fn_name, None)
                if fn is None:
                    return False
                button = fn()
            return self.mouseWatcherNode.is_button_down(button)
        except Exception:
            return False

    def _action_down(self, action):
        return self._key_is_down(self.bindings.get(action, DEFAULT_BINDINGS[action]))

    def _perform_action(self, action):
        if self.game_state != "playing":
            return
        if action == "attack":
            self._attack()
        elif action == "potion":
            if self.player_potions > 0 and self.player_hp < 100:
                self.player_potions -= 1
                self.player_hp = min(100, self.player_hp + 35)
                self._notify("İksir kullanıldı: +35 can")
            else:
                self._notify("İksir yok veya can zaten dolu")
        elif action == "full_potion":
            if self.full_potions > 0 and self.player_hp < 100:
                self.full_potions -= 1
                self.player_hp = 100
                self._notify("Tam can iksiri kullanıldı")
            else:
                self._notify("Tam can iksiri yok veya can dolu")
        elif action == "pause":
            self.show_pause()

    def _spawn_warrior(self, parent, color=(0.45, 0.11, 0.10, 1), accent=(0.78, 0.59, 0.26, 1), boss=False):
        root = parent.attachNewNode("spartan-warrior")
        skin = (0.63, 0.40, 0.27, 1)
        scale = 1.42 if boss else 1.0
        # Tunic torso and skirt.
        torso = make_sphere(root, "torso", color); torso.setScale(0.62, 0.42, 0.77); torso.setPos(0, 0, 1.43)
        skirt = make_box(root, "tunic-skirt", 0.92, 0.62, 0.50, color); skirt.setPos(0, 0, 0.92)
        # Legs and bronze greaves.
        for side in (-1, 1):
            leg = make_cylinder(root, "leg", skin); leg.setScale(0.19, 0.22, 0.73); leg.setPos(side * 0.22, 0, 0.16)
            shin = make_box(root, "greave", 0.24, 0.28, 0.36, accent); shin.setPos(side * 0.22, 0.035, 0.25)
            arm = make_sphere(root, "arm", skin); arm.setScale(0.21, 0.23, 0.47); arm.setPos(side * 0.48, 0.02, 1.50)
            bracer = make_box(root, "bracer", 0.22, 0.30, 0.27, accent); bracer.setPos(side * 0.50, 0.06, 1.24)
        # Head, helmet and crimson crest.
        head = make_sphere(root, "head", skin); head.setScale(0.31, 0.29, 0.33); head.setPos(0, 0.015, 2.12)
        helmet = make_sphere(root, "bronze-helmet", accent); helmet.setScale(0.36, 0.34, 0.24); helmet.setPos(0, 0.015, 2.31)
        brow = make_box(root, "helmet-brow", 0.61, 0.10, 0.12, (0.25, 0.20, 0.13, 1)); brow.setPos(0, 0.275, 2.22)
        crest = make_box(root, "red-crest", 0.13, 0.26, 0.53, (0.49, 0.035, 0.045, 1)); crest.setPos(0, -0.02, 2.62)
        crest2 = make_box(root, "crest-front", 0.35, 0.13, 0.11, (0.62, 0.045, 0.045, 1)); crest2.setPos(0, 0.03, 2.75)
        cape = make_box(root, "cape", 0.80, 0.09, 1.20, (0.27, 0.025, 0.035, 1)); cape.setPos(0, -0.32, 1.55); cape.setP(-7)
        # Large shield on the left side with a central boss.
        shield = make_cylinder(root, "shield", (0.28, 0.20, 0.11, 1), 12)
        shield.setScale(0.63, 0.76, 0.12); shield.setP(90); shield.setPos(-0.58, 0.23, 1.32)
        shield_ring = make_cylinder(root, "shield-rim", accent, 12)
        shield_ring.setScale(0.67, 0.80, 0.13); shield_ring.setP(90); shield_ring.setPos(-0.58, 0.21, 1.32)
        boss_mark = make_sphere(root, "shield-boss", accent); boss_mark.setScale(0.14, 0.10, 0.14); boss_mark.setPos(-0.58, 0.37, 1.32)
        weapon = root.attachNewNode("sword-pivot")
        weapon.setPos(0.53, 0.21, 1.25)
        blade = make_box(weapon, "sword-blade", 0.10, 0.07, 0.90, (0.73, 0.79, 0.85, 1)); blade.setPos(0, 0, 0.42)
        guard = make_box(weapon, "sword-guard", 0.34, 0.11, 0.09, accent); guard.setPos(0, 0, 0.04)
        grip = make_cylinder(weapon, "sword-grip", (0.17, 0.09, 0.035, 1)); grip.setScale(0.08, 0.08, 0.25); grip.setPos(0, 0, -0.12)
        root.setScale(scale)
        return root, weapon

    def _remove_battle_models(self):
        for node in (self.player_root, self.enemy_root):
            if node is not None:
                node.removeNode()
        self.player_root = self.enemy_root = None
        self.player_weapon = self.enemy_weapon = None

    def start_battle(self, mode="classic"):
        self._hide_cover(); self._clear_ui(); self._remove_battle_models()
        self.mode = mode
        self.game_state = "playing"
        self.player_hp = 100.0
        self.enemy_hp = 240.0 if mode == "boss" else 100.0
        self.player_potions = 3
        self.full_potions = 1
        self.player_attack_cd = self.enemy_attack_cd = 0.0
        self.prev_action = {}
        self.hit_flash = self.enemy_hit_flash = 0.0
        self.round_time = 0.0
        self.hill_time_left = 120.0
        self.round_number = max(1, int(self.progress.get("classic_round", 1))) if mode == "classic" else 1
        self.enemy_damage = 13.0 if mode == "boss" else 7.0
        self.player_damage = 24.0 if mode == "boss" else 22.0
        self.enemy_scale = 1.48 if mode == "boss" else 1.0
        self.player_root, self.player_weapon = self._spawn_warrior(self.world_root, (0.38, 0.055, 0.045, 1), (0.80, 0.60, 0.25, 1))
        self.enemy_root, self.enemy_weapon = self._spawn_warrior(self.world_root,
            (0.12, 0.19, 0.30, 1) if mode != "boss" else (0.17, 0.055, 0.045, 1),
            (0.48, 0.51, 0.54, 1) if mode != "boss" else (0.88, 0.24, 0.08, 1),
            boss=mode == "boss")
        self.player_root.setPos(0, -2.5, 0)
        self.enemy_root.setPos(random.uniform(-1.1, 1.1), 4.4, 0)
        self.player_root.setH(0)
        self.enemy_root.setH(180)
        self.camera.setPos(0, -12.5, 5.6)
        self.camera.lookAt(0, 0.7, 1.5)
        self._create_hud()
        title = {"classic":"KLASİK TUR", "hill":"TEPENİN KRALI", "boss":"BOSS SAVAŞI", "endless":"SONSUZ MOD"}.get(mode, "ARENA")
        self._notify(f"{title} başladı • WASD ile hareket et")

    def _create_hud(self):
        self._clear_ui()
        self.hud_labels["title"] = self._label("", (-1.70, 0, 0.91), 0.037, (1, 0.82, 0.47, 1), align=TextNode.ALeft)
        self.hud_labels["hp"] = self._label("CAN 100 / 100", (-1.70, 0, 0.82), 0.032, (1, 0.88, 0.83, 1), align=TextNode.ALeft)
        self.hud_labels["enemy"] = self._label("DÜŞMAN 100 / 100", (1.70, 0, 0.91), 0.034, (1, 0.72, 0.57, 1), align=TextNode.ARight)
        self.hud_labels["info"] = self._label("WASD: HAREKET    SOL TIK: SALDIRI    SHIFT: BLOK    Q/E: İKSİR    ESC: DURAKLAT",
                                                    (0, 0, -0.91), 0.025, (0.92, 0.88, 0.80, 1))
        self.hud_labels["status"] = self._label("", (0, 0, 0.67), 0.032, (1, 0.83, 0.48, 1))
        self._refresh_hud()

    def _refresh_hud(self):
        title = {"classic":f"KLASİK TUR • TUR {self.round_number}", "hill":"TEPENİN KRALI • 2 DAKİKA DAYAN",
                 "boss":"BOSS SAVAŞI", "endless":f"SONSUZ MOD • DALGA {self.round_number}"}.get(self.mode, "SPARTA ARENA")
        if "title" in self.hud_labels:
            self.hud_labels["title"].setText(title)
            self.hud_labels["hp"].setText(f"CAN {int(max(0,self.player_hp))} / 100   •   İKSİR {self.player_potions}   •   TAM CAN {self.full_potions}")
            self.hud_labels["enemy"].setText(f"DÜŞMAN {int(max(0,self.enemy_hp))} / {240 if self.mode=='boss' else 100}")

    def show_pause(self):
        if self.game_state != "playing":
            return
        self.game_state = "paused"
        self._clear_ui()
        self._label("OYUN DURAKLATILDI", (0, 0, 0.48), 0.066, (1, 0.82, 0.45, 1))
        self._button("DEVAM ET", (0, 0, 0.18), self.resume_game, 0.048, 9.0)
        self._button("AYARLAR / TUŞ DEĞİŞTİR", (0, 0, -0.03), self.show_pause_settings, 0.039, 12.0)
        self._button("ANA MENÜ", (0, 0, -0.25), self.show_main_menu, 0.043, 8.0)

    def resume_game(self):
        self._create_hud()
        self.game_state = "playing"

    def show_pause_settings(self):
        self.show_settings()
        # A return action is provided so a player can go back to the paused match.
        self._button("DURAKLATILMIŞ OYUNA DÖN", (0, 0, -0.91), self.resume_game, 0.028, 11.0)

    def _attack(self):
        if self.game_state != "playing" or self.player_attack_cd > 0:
            return
        self.player_attack_cd = 0.44
        if self.player_weapon:
            self.player_weapon.setP(-70)
        if self.player_root and self.enemy_root:
            p = self.player_root.getPos(self.world_root)
            e = self.enemy_root.getPos(self.world_root)
            distance = vec_len2((p.x, p.y), (e.x, e.y))
            if distance < (3.55 if self.mode == "boss" else 3.1):
                self.enemy_hp -= self.player_damage
                self.enemy_hit_flash = 0.16
                if self.enemy_hp <= 0:
                    self._enemy_defeated()
                else:
                    self._notify("VURUŞ! Düşmana hasar verdin")
            else:
                self._notify("Menzil dışında — düşmana yaklaş")

    def _enemy_defeated(self):
        self.progress["wins"] = int(self.progress.get("wins", 0)) + 1
        self.progress["gold"] = int(self.progress.get("gold", 500)) + (150 if self.mode == "boss" else 30)
        self.progress["achievements"] = list(self.progress.get("achievements", []))
        if "İlk Zafer" not in self.progress["achievements"]:
            self.progress["achievements"].append("İlk Zafer")
        if self.mode == "boss":
            self.progress["boss_wins"] = int(self.progress.get("boss_wins", 0)) + 1
            self._finish_match(True, "BOSS YENİLDİ! +150 ALTIN")
        elif self.mode == "hill":
            self.enemy_hp = 100
            self.enemy_root.setPos(random.uniform(-2, 2), random.uniform(2.7, 5.5), 0)
            self.round_number += 1
            self._notify("Rakip yenildi! Yeni rakip geliyor.")
        elif self.mode == "endless":
            self.progress["endless_kills"] = int(self.progress.get("endless_kills", 0)) + 1
            self.round_number += 1
            self.enemy_hp = min(180, 100 + (self.round_number - 1) * 4)
            self.enemy_root.setPos(random.uniform(-2, 2), random.uniform(3.5, 6.0), 0)
            self._notify(f"DALGA {self.round_number}! Düşmanlar güçleniyor.")
        else:
            self.round_number += 1
            self.progress["classic_round"] = max(int(self.progress.get("classic_round", 1)), self.round_number)
            if self.round_number > 120:
                self._finish_match(True, "120 TUR TAMAMLANDI! EFSANE SPARTALI!")
            else:
                self.enemy_hp = 100 + min(60, (self.round_number // 5) * 4)
                self.enemy_damage = 7 + min(8, self.round_number // 12)
                self.enemy_root.setPos(random.uniform(-2.5, 2.5), random.uniform(3.7, 6.0), 0)
                self._notify(f"TUR {self.round_number}! +30 ALTIN")
        self.progress["achievements"] = list(self.progress.get("achievements", []))
        atomic_write_json(PROGRESS_PATH, self.progress)

    def _finish_match(self, won, message):
        self.game_state = "result"
        self.result_reason = message
        atomic_write_json(PROGRESS_PATH, self.progress)
        self._clear_ui()
        self._label("ZAFER!" if won else "YENİLGİ", (0, 0, 0.43), 0.080, (1, 0.83, 0.44, 1) if won else (0.95, 0.28, 0.22, 1))
        self._label(message, (0, 0, 0.20), 0.038)
        self._label(f"TOPLAM ZAFER: {self.progress['wins']}     ALTIN: {self.progress['gold']}", (0, 0, 0.04), 0.033)
        self._button("TEKRAR OYNA", (0, 0, -0.22), lambda: self.start_battle(self.mode), 0.043, 8.5)
        self._button("ANA MENÜ", (0, 0, -0.44), self.show_main_menu, 0.042, 7.0)

    def _notify(self, message):
        self.notice_until = time.monotonic() + 1.8
        if self.notice_label:
            try: self.notice_label.destroy()
            except Exception: pass
            try: self.gui.remove(self.notice_label)
            except ValueError: pass
        self.notice_label = DirectLabel(text=message, pos=(0, 0, 0.60), scale=0.030,
                                        text_fg=(1.0, 0.80, 0.42, 1), frameColor=(0.02, 0.02, 0.03, 0.45))
        self.gui.append(self.notice_label)

    def launch_legacy(self):
        """Open the original V57 feature-complete Pygame program, preserving its modes."""
        if getattr(sys, "frozen", False):
            exe = Path(sys.executable).resolve().parent / "SpartaArenaV57.exe"
            if not exe.is_file():
                self._clear_ui()
                self._label("V57 OYUN DOSYASI BULUNAMADI", (0, 0, 0.2), 0.05, (1, 0.3, 0.2, 1))
                self._label("SpartaArena.exe ile SpartaArenaV57.exe aynı klasörde olmalı.", (0, 0, -0.02), 0.03)
                self._button("GERİ", (0, 0, -0.25), self.show_main_menu, 0.04, 5)
                return
            command = [str(exe)]
        else:
            legacy = PROJECT_DIR / "legacy_v57" / "main.py"
            command = [sys.executable, str(legacy)]
        save_dir = Path.home() / "Documents" / "SpartaArena"
        save_dir.mkdir(parents=True, exist_ok=True)
        try:
            subprocess.Popen(command, cwd=str(save_dir))
            self.userExit()
        except OSError as exc:
            self._notify(f"V57 açılamadı: {exc}")

    def update(self, task):
        dt = min(0.05, max(0.0, globalClock.getDt()))
        now = time.monotonic()
        for flame, phase in self.flames:
            if not flame.isEmpty():
                flame.setZ(1.27 + math.sin(now * 9 + phase) * 0.08)
                flame.setSx(0.22 + abs(math.sin(now * 8 + phase)) * 0.05)
        if self.notice_label and now > self.notice_until:
            try: self.notice_label.destroy()
            except Exception: pass
            try: self.gui.remove(self.notice_label)
            except ValueError: pass
            self.notice_label = None
        if self.game_state != "playing" or not self.player_root or not self.enemy_root:
            return task.cont

        self.player_attack_cd = max(0, self.player_attack_cd - dt)
        self.enemy_attack_cd = max(0, self.enemy_attack_cd - dt)
        self.hit_flash = max(0, self.hit_flash - dt)
        self.enemy_hit_flash = max(0, self.enemy_hit_flash - dt)
        if self.player_weapon and self.player_attack_cd < 0.25:
            self.player_weapon.setP(0)

        # Keyboard actions are edge-triggered where needed, so holding Q cannot burn all potions.
        for action in ("attack", "potion", "full_potion", "pause"):
            down = self._action_down(action)
            if down and not self.prev_action.get(action, False):
                if not self.bindings[action].startswith("mouse"):
                    self._perform_action(action)
            self.prev_action[action] = down
            if self.game_state != "playing":
                return task.cont

        move_x = (1 if self._action_down("right") else 0) - (1 if self._action_down("left") else 0)
        move_y = (1 if self._action_down("forward") else 0) - (1 if self._action_down("back") else 0)
        move_mag = math.hypot(move_x, move_y)
        if move_mag:
            move_x /= move_mag; move_y /= move_mag
            p = self.player_root.getPos(self.world_root)
            px = p.getX() + move_x * 6.0 * dt
            py = p.getY() + move_y * 6.0 * dt
            radius = math.hypot(px, py)
            if radius > 8.5:
                px *= 8.5 / radius
                py *= 8.5 / radius
            self.player_root.setPos(self.world_root, px, py, p.getZ())
            if move_mag > 0:
                self.player_root.setH(math.degrees(math.atan2(move_x, move_y)))

        player_pos = self.player_root.getPos(self.world_root)
        enemy_pos = self.enemy_root.getPos(self.world_root)
        dx, dy = player_pos.getX() - enemy_pos.getX(), player_pos.getY() - enemy_pos.getY()
        distance = math.hypot(dx, dy)
        if distance > 1.75:
            speed = 1.45 if self.mode == "boss" else 1.85
            ex = enemy_pos.getX() + (dx / max(distance, 0.001)) * speed * dt
            ey = enemy_pos.getY() + (dy / max(distance, 0.001)) * speed * dt
            self.enemy_root.setPos(self.world_root, ex, ey, enemy_pos.getZ())
        self.enemy_root.setH(math.degrees(math.atan2(dx, dy)))

        if distance < (2.25 if self.mode == "boss" else 1.95) and self.enemy_attack_cd <= 0:
            self.enemy_attack_cd = 1.25 if self.mode != "boss" else 0.9
            damage = self.enemy_damage
            if self._action_down("block"):
                damage *= 0.38
                self._notify("Blok başarılı! Hasar azaltıldı.")
            self.player_hp -= damage
            self.hit_flash = 0.18
            if self.player_hp <= 0:
                self._finish_match(False, "Savaşçı yenildi. İksirlerini ve bloğu kullanmayı dene.")
                return task.cont

        if self.mode == "hill":
            self.hill_time_left -= dt
            if self.hill_time_left <= 0:
                self.progress["wins"] = int(self.progress.get("wins", 0)) + 1
                self.progress["gold"] = int(self.progress.get("gold", 500)) + 100
                self._finish_match(True, "TEPENİN KRALI! 120 SANİYE DAYANDIN. +100 ALTIN")
                return task.cont
        if now - self.last_hud_update > 0.15:
            self.last_hud_update = now
            self._refresh_hud()
        # Smooth third-person camera, avoid per-frame expensive rebuilds.
        px, py = player_pos.getX(), player_pos.getY()
        cam_target = Point3(px * 0.48, py - 0.8, 1.45)
        current = self.camera.getPos(self.render)
        desired = Point3(px * 0.52, py - 12.4, 5.4)
        blend = min(1.0, dt * 3.5)
        self.camera.setPos(current + (desired - current) * blend)
        self.camera.lookAt(cam_target)
        return task.cont


if __name__ == "__main__":
    app = SpartaArena3D()
    app.run()
