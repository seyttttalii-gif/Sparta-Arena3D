# Proje durumu — gerçekçi kapsam

- `main.py`: Panda3D tabanlı gerçek 3D PC arena. Prosedürel 3D geometri, üçüncü şahıs kamera, aydınlatma, düşman yapay zekâsı, klasik tur / tepenin kralı / boss / sonsuz arena, kalıcı ilerleme ve değiştirilebilir klavye/fare bağları içerir.
- `legacy_v57/main.py`: optimize edilmiş orijinal Pygame V57 oyun giriş noktası. Geniş V57 menüleri ve eski sistemler korunur.
- `original_v57_source/`: yüklenen V57 Android kaynak arşivinin açılmış kopyasıdır.
- `assets/`: sade sinematik kapak ve uygulama simgesi.
- `.github/workflows/windows-build.yml`: Windows üzerinde iki EXE üretir; ikisi bir ZIP içinde Artifact olarak kaydedilir.

**Dürüst sınır:** V57'nin dünya fethi, şehir/kervan, deniz, balıkçılık, mağaza, iksir, başarımlar ve diğer tüm sistemleri yeni 3D motora birebir taşınmış değildir; mevcut optimize edilmiş V57 uygulamasında erişilebilir ve korunmuştur. Yeni 3D motor şu an 4 oynanabilir arena modunu içerir. Gerçekten bütün sistemleri 3D'ye taşımak için her sistemin mekaniğini/arayüzünü yeni motor üzerinde ayrı ayrı yeniden yazıp test etmek gerekir.

**Test sınırı:** Kod sözdizimi kontrolü yapılmıştır. Bu oturumda Panda3D bağımlılıklarını internet erişimi olmadığı için kurup oyunu gerçek bir GPU penceresinde çalıştırmak, Windows EXE'yi üretmek veya FPS ölçmek mümkün olmadı. Windows derlemesi GitHub Actions'ta yapılmalıdır.
