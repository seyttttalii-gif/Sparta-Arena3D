@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.11 veya yenisi bulunamadi.
  echo https://www.python.org/downloads/ adresinden Python kur.
  echo Kurulumda Add Python to PATH kutusunu sec.
  pause
  exit /b 1
)
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Gerekli kutuphaneler kurulamadi. Internet baglantisini kontrol et.
  pause
  exit /b 1
)
python main.py
if errorlevel 1 (
  echo Oyun bir hatayla kapandi. Yukaridaki hata metnini sakla.
  pause
)
